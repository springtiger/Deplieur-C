// include avec les textes (encodage utf-8)

char const * const textes[] = {
  "Nom fichier :",
  "Echelle :",
  "Erreur ouverture fichier",
  "Erreur fermeture fichier",
  "Format A(0..5) :",
  "points",
  "faces",
  "Taille des nombres (d�faut 11) :",
  "Hauteur des languettes (d�faut 10) :",
  "1er triangle :",
  "gabarit.pdf"
};

